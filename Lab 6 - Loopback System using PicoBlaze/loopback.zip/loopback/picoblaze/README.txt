CSD Spring 2015
Picoblaze Assembler

To assemble, run assembler.exe. When prompted, enter the filename for your program. It should be in the format:
  <filename>.psm
The assembler will generate a Verilog file named after your program. The file will be named:
  <filename>.v
Add this Verilog file to your project; it is the program ROM for PicoBlaze. 

The maximum size for a PSM file is 4k lines. 
