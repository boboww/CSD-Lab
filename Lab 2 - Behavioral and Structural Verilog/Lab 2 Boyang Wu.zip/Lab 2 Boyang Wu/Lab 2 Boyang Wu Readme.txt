My working folder is Lab2Combined which has all the files I used in this lab

The lab report and this readme are outside of the folders but still in the main zipped folder

Problem 1 and 2 are both openable as standalone projects and have the relevant files (as instructed in lab instructions)